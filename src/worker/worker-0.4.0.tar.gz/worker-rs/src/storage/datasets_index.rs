use std::{collections::HashMap, str::FromStr, sync::Arc};

use subsquid_messages::{DatasetChunks, WorkerAssignment};

use crate::types::{
    dataset::Dataset,
    state::{ChunkRef, ChunkSet},
};

use super::layout::DataChunk;

#[derive(Default)]
pub struct DatasetsIndex {
    datasets: HashMap<Arc<Dataset>, DatasetIndex>,
    http_headers: Vec<(String, String)>,
}

pub struct RemoteFile {
    pub url: String,
    pub name: Arc<str>,
}

struct DatasetIndex {
    url: String,
    files: HashMap<DataChunk, Vec<Arc<str>>>,
}

impl DatasetsIndex {
    pub fn list_files(&self, dataset: &Dataset, chunk: &DataChunk) -> Option<Vec<RemoteFile>> {
        let ds = self.datasets.get(dataset)?;
        ds.files.get(chunk).map(|files| {
            files
                .iter()
                .map(|name| RemoteFile {
                    url: format!("{}/{}", ds.url, name),
                    name: name.clone(),
                })
                .collect()
        })
    }

    pub fn get_headers(&self) -> &[(String, String)] {
        &self.http_headers
    }
}

// Reuses memory building both ChunkSet and DatasetsIndex simultaneously
pub fn parse_assignment(assignment: WorkerAssignment) -> anyhow::Result<(ChunkSet, DatasetsIndex)> {
    let mut datasets = HashMap::new();
    let mut chunk_set = ChunkSet::new();

    let filename_refs: HashMap<u32, Arc<str>> = assignment
        .known_filenames
        .into_iter()
        .enumerate()
        .map(|(i, filename)| (i as u32, Arc::from(filename.as_str())))
        .collect();

    for DatasetChunks {
        dataset_id,
        download_url,
        chunks,
        ..
    } in assignment.dataset_chunks
    {
        let dataset_id: Arc<Dataset> = Arc::from(dataset_id);
        let mut dataset_files = HashMap::new();
        for chunk in chunks {
            let data_chunk = DataChunk::from_str(&chunk.path)
                .map_err(|_| anyhow::anyhow!("Invalid chunk path"))?;
            let files = chunk
                .filenames
                .iter()
                .map(|index| filename_refs.get(index).unwrap().clone())
                .collect();
            chunk_set.insert(ChunkRef {
                dataset: dataset_id.clone(),
                chunk: data_chunk.clone(),
            });
            dataset_files.insert(data_chunk, files);
        }
        datasets.insert(
            dataset_id,
            DatasetIndex {
                url: download_url,
                files: dataset_files,
            },
        );
    }
    Ok((
        chunk_set,
        DatasetsIndex {
            datasets,
            http_headers: assignment
                .http_headers
                .into_iter()
                .map(|header| (header.name, header.value))
                .collect(),
        },
    ))
}
